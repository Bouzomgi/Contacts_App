/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contactsapp;

/**
 *
 * @author bao5148
 */

// Contact.java
public class Contact {
   private String firstName; // First name
   private String lastName; // Last name
   private String homeAddress; // Home Address
   private String phoneNumber; // Phone Number
   private String emailAddress; // Email Address

   private String largeImage; // source of contact cover's full-size image

   public Contact(String firstName, String lastName, String homeAddress, String phoneNumber, String emailAddress, 
        String largeImage) {
      this.firstName = (firstName + " ");
      this.lastName = lastName;
      this.homeAddress = homeAddress;
      this.phoneNumber = phoneNumber;
      this.emailAddress = emailAddress;
      
      this.largeImage = largeImage;
   }
   
   //Getters and senders for all my variables
   
   public String getFirstName() {return firstName;}

   public void setFirstName(String firstName) {this.firstName = (firstName + " ");}
   
   
   public String getLastName() {return lastName;}

   public void setLastName(String lastName) {this.lastName = lastName;}
   

   public String getHomeAddress() {return homeAddress;}

   public void setHomeAddress(String homeAddress) {this.homeAddress = homeAddress;} 
   
   
   public String getPhoneNumber() {return phoneNumber;}

   public void setPhoneNumber(String phoneNumber) {this.phoneNumber = phoneNumber;}  
   
   
   public String getEmailAddress() {return emailAddress;}

   public void setEmailAddress(String emailAddress) {this.emailAddress = emailAddress;}  
   
   
   public String getLargeImage() {return largeImage;}

   public void setLargeImage(String largeImage) {this.largeImage = largeImage;}
   
   
   @Override
   public String toString() {return (getFirstName() + getLastName());}
}


/**************************************************************************
 * (C) Copyright 1992-2018 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
