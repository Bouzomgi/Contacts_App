package contactsapp;

import javafx.scene.control.TextField;

import java.io.File;
import javafx.scene.control.Button;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Callback;
import javafx.event.ActionEvent;
import javafx.stage.FileChooser;
import javafx.scene.input.MouseEvent;

public class ContactsAppController {

    Contact currentContact;

    private String currentImage;

    @FXML
    private Button Add;

    @FXML
    private Button save;

    @FXML
    private Button delete;

    @FXML
    private TextField lastName;

    @FXML
    private TextField firstName;

    @FXML
    private TextField emailAddress;

    @FXML
    private TextField phoneNumber;

    @FXML
    private TextField homeAddress;

    @FXML
    private ImageView image;
    // instance variables for interacting with GUI
    @FXML
    private ListView<Contact> contactsListView;
//    @FXML private ImageView contactImageView;

    // stores the list of Contact Objects
    private final ObservableList<Contact> contactsList
            = FXCollections.observableArrayList();

    public void initialize() {
        
        //When adding a contact, sort it by name
        contactsListView.setItems(contactsList.sorted());

        // when ListView selection changes, show large contact in ImageView
        contactsListView.getSelectionModel().selectedItemProperty().
                addListener(
                        new ChangeListener<Contact>() {
                    @Override
                    public void changed(ObservableValue<? extends Contact> ov,
                            Contact oldValue, Contact newValue) {
                        
                        //adjust the large viewer's values when a thumbnail is selected
                        firstName.setText(newValue.getFirstName());
                        lastName.setText(newValue.getLastName());
                        emailAddress.setText(newValue.getEmailAddress());
                        homeAddress.setText(newValue.getHomeAddress());
                        phoneNumber.setText(newValue.getPhoneNumber());
                        currentImage = newValue.getLargeImage();

                        image.setImage(new Image(currentImage));
                        currentContact = newValue;

                        //sets image of the large viewer
                        if (currentImage == null) {
                            image.setImage(null);
                        } else {
                            image.setImage(new Image(currentImage));
                        }
                        currentContact = newValue;

                    }
                }
                );

        // set custom ListView cell factory
        contactsListView.setCellFactory(
                new Callback<ListView<Contact>, ListCell<Contact>>() {
            @Override
            public ListCell<Contact> call(ListView<Contact> listView) {
                return new ContactImageTextCell();
            }
        }
        );
    }

    @FXML
    void add(ActionEvent event) {
        //when adding a contact, add fresh textboxes
        currentContact = null;
        firstName.setText("");
        lastName.setText("");
        emailAddress.setText("");
        phoneNumber.setText("");
        homeAddress.setText("");
        image.setImage(null);

    }

    @FXML
    void delete(ActionEvent event) {
        //when deleting, remove the current contact from the contact list. If the contact you are removing
        //is the last contact, empty the information fields
        contactsList.remove(currentContact);
        if (contactsList.isEmpty()) {
            currentContact = null;
            firstName.setText(null);
            lastName.setText(null);
            emailAddress.setText(null);
            phoneNumber.setText(null);
            homeAddress.setText(null);
            image.setImage(null);
        }
        //set the large viewer's contact to the next most recent contact
        currentContact = contactsList.get(0);

    }

    @FXML
    void loadImage(MouseEvent event) {
    //shows GUI when attempting to add an image into the contact builder and fits its path to currentImage
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select File");

        // display files in folder from which the app was launched
        fileChooser.setInitialDirectory(new File("."));

        // display the FileChooser
        File file = fileChooser.showOpenDialog(
                image.getScene().getWindow());

        if (file != null) {
            currentImage = file.toURI().toString();
            image.setImage(new Image(currentImage));
        }
    }

    @FXML
    void save(ActionEvent event) {
        //this case accounts for adding a new contact. It checkes to make sure the contact is fresh,
        //it has a first or last name field, and it has an image.
        if (currentContact == null) {
            if (!((firstName.getText().equalsIgnoreCase("")) & (lastName.getText().equalsIgnoreCase("")))) {
                if (image.getImage() != null) {
        //now, the program makes a new contact object with the given fields' information, and adds that contact to the 
        //contact list.
                    currentContact = new Contact(firstName.getText(), lastName.getText(),
                            emailAddress.getText(), phoneNumber.getText(), homeAddress.getText(), currentImage);
                    contactsList.add(currentContact);
                }
            }
            
        //this case accounts for saving changes to an already established contact. It sets the new fields to 
        //the current contact.
        } else if (currentContact != null) {

            currentContact.setFirstName(firstName.getText());
            currentContact.setLastName(lastName.getText());
            currentContact.setEmailAddress(emailAddress.getText());
            currentContact.setPhoneNumber(phoneNumber.getText());
            currentContact.setHomeAddress(homeAddress.getText());
            currentContact.setLargeImage(currentImage);

        //this segment of code refreshes the thumbnail viewer every time you make a new save.    
            contactsListView.setCellFactory(
                    new Callback<ListView<Contact>, ListCell<Contact>>() {
                @Override
                public ListCell<Contact> call(ListView<Contact> listView) {
                    return new ContactImageTextCell();
                }
            }
            );
        }

    }

}
